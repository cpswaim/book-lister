import React from 'react';

export default class Banner extends React.Component {
    render() {
        return (
            <div className="banner navbar">
                <div className="navbar-header">
                    <a className="navbar-brand active title">
                        BookLister
                    </a>
                </div>
                {/*<a className="btn-refresh btn btn-raised btn-info fa fa-refresh">
                    <div className="ripple-container"></div>
                </a>*/} 
            </div>
        );
    }
}