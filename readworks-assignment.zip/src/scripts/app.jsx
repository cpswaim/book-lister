import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import './app.scss';

import configureStore from './store';

import BookLister from './views/BookLister/BookListerContainer'

const store = configureStore();

document.addEventListener("DOMContentLoaded", function(event) {
    ReactDOM.render(
            <Provider store={store}>
            	<BookLister />
            </Provider>,
        document.getElementById('app')
    );
})