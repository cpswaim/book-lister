import React, { Component } from 'react';
import LoadMask from '../../components/LoadMask/LoadMask';
import Banner from '../../components/Banner/Banner';

import 'bootstrap-material-design/dist/js/material.min.js';
import 'bootstrap-material-design/dist/js/ripples.min.js';

export default class BookLister extends Component {
    constructor(props){
        super(props);
    }
    render() {
        const {
            books,
            page
        } = this.props;

        let currentBooks = books[page];

        return (
            <div className="application container">
                <LoadMask />
                <Banner />
                {JSON.stringify(currentBooks)}
            </div>
        );
    }
}