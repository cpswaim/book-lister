import { connect } from 'react-redux';
import BookLister from './BookLister';

const mapStateToProps = (state) => ({
  books: state.books,
  page: state.page
})

const mapDispatchToProps = (dispatch) => ({
	foo(){
		console.log("foo");
	}
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(BookLister);