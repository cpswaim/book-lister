const initialState = {
	"isLoading": false,
	"books": {
		0: []
	},
	"page": 0,
	"count": 5
}

export default function(state = initialState){
	return state;
}