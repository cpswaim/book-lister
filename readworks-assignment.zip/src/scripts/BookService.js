const class BookService {
    get(){
        return [
            {"title":"Cracking the Coding Interview","author":"Gayle Laakmann McDowell","year_published":"2015"},
            {"title":"HTML and CSS: Design and Build Websites","author":"Jon Duckett","year_published":"2011"},
            {"title":"Raspberry Pi 3: Beginner to Pro – Step by Step Guide","author":"Timothy Short","year_published":"2016"},
            {"title":"SQL: The Ultimate Guide From Beginner To Expert - Learn And Master SQL In No Time!","author":"Peter Adams","year_published":"2016"},
            {"title":"The LEGO MINDSTORMS EV3 Discovery Book (Full Color): A Beginner's Guide to Building and Programming Robots","author":"Laurens Valk","year_published":"2014"},
            {"title":"Web Design with HTML, CSS, JavaScript and jQuery Set","author":"Jon Duckett","year_published":"2014"},
            {"title":"Python Crash Course: A Hands-On, Project-Based Introduction to Programming","author":"Eric Matthes","year_published":"2015"},
            {"title":"Make Your Own Neural Network","author":"Tariq Rashid","year_published":"2016"},
            {"title":"3D Game Programming for Kids: Create Interactive Worlds with JavaScript","author":"Chris Strom","year_published":"2013"},
            {"title":"Learn to Program with Minecraft: Transform Your World with the Power of Python","author":"Craig Richardson","year_published":"2015"},
            {"title":"Raspberry Pi 3: Beginner to Pro – Step by Step Guide","author":"Timothy Short","year_published":"2016"},
            {"title":"Python for Kids: A Playful Introduction to Programming","author":"Jason R. Briggs","year_published":"2012"},
            {"title":"Programming the Raspberry Pi, Second Edition: Getting Started with Python","author":"Simon Monk","year_published":"2015"},
            {"title":"Make: Electronics: Learning Through Discovery","author":"Charles Platt","year_published":"2015"},
            {"title":"Automate the Boring Stuff with Python: Practical Programming for Total Beginners","author":"Al Sweigart","year_published":"2015"},
            {"title":"Hackers: Heroes of the Computer Revolution: 25th Anniversary Edition","author":"Steven Levy","year_published":"2015"},
            {"title":"Clean Code: A Handbook of Agile Software Craftsmanship","author":"Robert C. Martin","year_published":"2008"}
        ]
    }
};

export default BookService;